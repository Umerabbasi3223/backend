import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './CSS/LoginSignup.css';

const LoginSignup = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    rememberMe: false
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isAlreadyLoggedIn, setIsAlreadyLoggedIn] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const navigate = useNavigate();
  
  // Local login and register functions
  const login = async (email, password) => {
    try {
      console.log('Attempting login to:', 'http://localhost:4000/api/auth/login');
      const response = await fetch('http://localhost:4000/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();
      console.log('Login response:', data);

      if (data.success) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        return { success: true, user: data.user };
      } else {
        return { success: false, message: data.message };
      }
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, message: 'Unable to connect to server. Please check if backend is running.' };
    }
  };

  const register = async (name, email, password) => {
    try {
      console.log('Attempting register to:', 'http://localhost:4000/api/auth/register');
      const response = await fetch('http://localhost:4000/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password, role: 'user' })
      });

      const data = await response.json();
      console.log('Register response:', data);

      if (data.success) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        return { success: true, user: data.user };
      } else {
        return { success: false, message: data.message };
      }
    } catch (error) {
      console.error('Register error:', error);
      return { success: false, message: 'Unable to connect to server. Please check if backend is running.' };
    }
  };

  // Check if user is already logged in - FIXED: Removed auto-redirect
  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (token && userData) {
      try {
        const user = JSON.parse(userData);
        setLoggedInUser(user);
        setIsAlreadyLoggedIn(true);
      } catch (error) {
        console.error('Error parsing user data:', error);
      }
    }
    
    // Check for remember me
    const savedEmail = localStorage.getItem('rememberedEmail');
    if (savedEmail) {
      setFormData(prev => ({ ...prev, email: savedEmail, rememberMe: true }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    setError('');
  };

  const validateForm = () => {
    if (!formData.email.trim()) {
      setError('Email is required');
      return false;
    }
    
    if (!formData.password) {
      setError('Password is required');
      return false;
    }
    
    if (!isLogin) {
      if (!formData.name.trim()) {
        setError('Name is required');
        return false;
      }
      
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters');
        return false;
      }
      
      if (formData.password !== formData.confirmPassword) {
        setError('Passwords do not match');
        return false;
      }
    }
    
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      let result;
      
      if (isLogin) {
        result = await login(formData.email, formData.password);
      } else {
        result = await register(formData.name, formData.email, formData.password);
      }

      if (result.success) {
        // Handle remember me
        if (formData.rememberMe) {
          localStorage.setItem('rememberedEmail', formData.email);
        } else {
          localStorage.removeItem('rememberedEmail');
        }
        
        // Show success message
        const successMsg = isLogin 
          ? `Welcome back, ${result.user.name}!`
          : `Account created successfully, ${result.user.name}!`;
        
        setError({ type: 'success', message: successMsg });
        
        // Update logged in state
        setIsAlreadyLoggedIn(true);
        setLoggedInUser(result.user);
        
        // Redirect after showing message (optional)
        setTimeout(() => {
          navigate('/');
        }, 1500);
        
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
      console.error('Auth error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('rememberedEmail');
    setIsAlreadyLoggedIn(false);
    setLoggedInUser(null);
    setFormData({
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      rememberMe: false
    });
    setError({ type: 'success', message: 'Logged out successfully!' });
  };

  // Simple test credentials
  const fillTestCredentials = (isAdmin = false) => {
    if (isAdmin) {
      setFormData(prev => ({
        ...prev,
        email: 'admin@example.com',
        password: 'admin123'
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        email: 'user@example.com',
        password: 'user123'
      }));
    }
  };

  // Test backend connection
  const testBackendConnection = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:4000/api/auth/test');
      const data = await response.json();
      alert(`Backend connection test: ${data.message || 'Success!'}`);
    } catch (error) {
      alert(`Backend connection failed: ${error.message}. Make sure backend is running on port 4000.`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="loginsignup">
      <div className="loginsignup-container">
        {/* Show logged in user info */}
        {isAlreadyLoggedIn && (
          <div className="already-logged-in-overlay">
            <div className="already-logged-in">
              <div className="logged-in-message">
                <h3>👋 Welcome back, {loggedInUser?.name}!</h3>
                <p>You are already logged in as <strong>{loggedInUser?.email}</strong></p>
                <p className="role-badge">Role: {loggedInUser?.role}</p>
                <div className="logged-in-actions">
                  <button 
                    className="continue-btn"
                    onClick={() => navigate('/')}
                  >
                    🛍️ Continue Shopping
                  </button>
                  <button 
                    className="logout-btn"
                    onClick={handleLogout}
                  >
                    🔓 Logout
                  </button>
                  <button 
                    className="stay-btn"
                    onClick={() => setIsAlreadyLoggedIn(false)}
                  >
                    ✏️ Edit Profile / Login as different user
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main content - always shown but can be behind overlay */}
        <div style={{ opacity: isAlreadyLoggedIn ? 0.3 : 1 }}>
          {/* Left Panel - Branding */}
          <div className="login-branding">
            <div className="brand-content">
              <h1>Welcome to Shopper</h1>
              <p>Your one-stop destination for fashion and lifestyle</p>
              <div className="brand-features">
                <div className="feature">
                  <span>🚚</span>
                  <p>Free Shipping</p>
                </div>
                <div className="feature">
                  <span>💳</span>
                  <p>Secure Payment</p>
                </div>
                <div className="feature">
                  <span>↩️</span>
                  <p>Easy Returns</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Panel - Form */}
          <div className="login-form-panel">
            <div className="form-header">
              <h2>{isLogin ? 'Sign In' : 'Create Account'}</h2>
              <p>{isLogin ? 'Enter your credentials to continue' : 'Join thousands of happy customers'}</p>
            </div>

            {/* Connection Test Button */}
            <div className="connection-test">
              <button 
                onClick={testBackendConnection}
                className="test-connection-btn"
                disabled={loading}
              >
                🔌 Test Backend Connection
              </button>
            </div>

            {/* Error/Success Message */}
            {error && (
              <div className={`message ${typeof error === 'object' && error.type === 'success' ? 'success' : error.type === 'info' ? 'info' : 'error'}`}>
                {typeof error === 'string' ? error : error.message}
              </div>
            )}

            {/* Test Credentials (for development) */}
            <div className="test-credentials">
              <button 
                onClick={() => fillTestCredentials(true)}
                className="test-btn admin"
                disabled={loading}
              >
                👑 Fill Admin Credentials
              </button>
              <button 
                onClick={() => fillTestCredentials(false)}
                className="test-btn user"
                disabled={loading}
              >
                👤 Fill User Credentials
              </button>
            </div>

            {/* Tabs */}
            <div className="auth-tabs">
              <button 
                className={`tab ${isLogin ? 'active' : ''}`}
                onClick={() => setIsLogin(true)}
                disabled={loading}
              >
                Sign In
              </button>
              <button 
                className={`tab ${!isLogin ? 'active' : ''}`}
                onClick={() => setIsLogin(false)}
                disabled={loading}
              >
                Create Account
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="auth-form">
              {!isLogin && (
                <div className="form-group">
                  <label htmlFor="name">Full Name</label>
                  <input
                    id="name"
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter your full name"
                    disabled={loading}
                  />
                </div>
              )}
              
              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input
                  id="email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password</label>
                <div className="password-input">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Enter your password"
                    disabled={loading}
                  />
                  <button 
                    type="button"
                    className="toggle-password"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={loading}
                  >
                    {showPassword ? '🙈' : '👁️'}
                  </button>
                </div>
              </div>

              {!isLogin && (
                <div className="form-group">
                  <label htmlFor="confirmPassword">Confirm Password</label>
                  <div className="password-input">
                    <input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      placeholder="Confirm your password"
                      disabled={loading}
                    />
                    <button 
                      type="button"
                      className="toggle-password"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      disabled={loading}
                    >
                      {showConfirmPassword ? '🙈' : '👁️'}
                    </button>
                  </div>
                </div>
              )}

              {isLogin && (
                <div className="form-options">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      name="rememberMe"
                      checked={formData.rememberMe}
                      onChange={handleChange}
                      disabled={loading}
                    />
                    <span>Remember me</span>
                  </label>
                  <button 
                    type="button"
                    className="forgot-password"
                    onClick={() => alert('Password reset would be sent to your email')}
                    disabled={loading}
                  >
                    Forgot password?
                  </button>
                </div>
              )}

              <button 
                type="submit" 
                className="submit-btn"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner"></span>
                    {isLogin ? 'Signing In...' : 'Creating Account...'}
                  </>
                ) : (
                  isLogin ? 'Sign In' : 'Create Account'
                )}
              </button>
            </form>

            {/* Or Divider */}
            <div className="or-divider">
              <span>or</span>
            </div>

            {/* Social Login (Simplified) */}
            <div className="social-login">
              <button 
                type="button"
                className="social-btn google"
                onClick={() => alert('Google login would be implemented with OAuth')}
                disabled={loading}
              >
                <span className="social-icon">G</span>
                Continue with Google
              </button>
              
              <button 
                type="button"
                className="social-btn facebook"
                onClick={() => alert('Facebook login would be implemented with OAuth')}
                disabled={loading}
              >
                <span className="social-icon">f</span>
                Continue with Facebook
              </button>
            </div>

            {/* Terms and Conditions */}
            {!isLogin && (
              <div className="terms">
                <p>By creating an account, you agree to our</p>
                <p>
                  <a href="#terms">Terms of Service</a> and <a href="#privacy">Privacy Policy</a>
                </p>
              </div>
            )}

            {/* Switch Mode */}
            <div className="switch-mode">
              <p>
                {isLogin ? "Don't have an account? " : "Already have an account? "}
                <button 
                  type="button" 
                  onClick={() => setIsLogin(!isLogin)}
                  disabled={loading}
                >
                  {isLogin ? 'Sign Up' : 'Sign In'}
                </button>
              </p>
            </div>

            {/* Back to Home */}
            <div className="back-home">
              <Link to="/">
                ← Back to Home
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginSignup;